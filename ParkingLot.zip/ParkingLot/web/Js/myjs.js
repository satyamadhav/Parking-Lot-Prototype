/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

// find elements
$(function () {
    //called when key is pressed in textbox
    var rowindex = [];
    var rowi = 0;
    var num = 0;
    $("#numpl").keypress(function (e) {
        //if the letter is not digit then display error and don't type anything
        if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
            //display error message
            $("#errmsg").html("Digits Only").show().fadeOut("slow");
            return false;
        }
    });
    $('#addblock').hide();
    //var first="",second="";
    $('#tableDiv').on('click', 'tr button', function (e) {
        e.preventDefault();
        rowindex[rowi++] = $(this).closest('tr').attr('id');
        $(this).closest('tr').remove();
        $('#addblock').show();
    });



    $("#detailButton").click(function () {
        if ($("#numpl").val() != "") {
            num = $("#numpl").val();
            var table_body = '';
            var colors = ['Black', 'White', 'Blue', 'Red'];
            var charclass = ['A-ZA-Z'];
            //var thing = things[Math.floor(Math.random() * things.length)];
            table_body ='<tr><th>Reg No</th><th>Color</th><th>Slot No</th><th>Action</th></tr>';
            for (var i = 0; i < num; i++) {
                var tempvnum = Math.floor(Math.random() * 10000);
                var tempser = Math.floor(Math.random() * 10);
                var color = colors[Math.floor(Math.random() * colors.length)];
                var num1 = String.fromCharCode(65 + Math.floor(Math.random() * 10));
                var num2 = String.fromCharCode(65 + Math.floor(Math.random() * 10));
                table_body += '<tr id=' + (i + 1) + '><td>KA-0' + tempser + '-' + num1 + num2 + '-' + tempvnum + '</td><td>' + color + '</td><td>' + (i + 1) + '</td>' + '<td><button type="button"  id=' + (i + 1) + '>Deallocate</button></td></tr>';
            }

            //table_body += '</table>';
            $('#tableDiv').html(table_body);
        } else {
            alert('enter some number');
            return false;
        }
        
        $('#addv').blur(function(){
            var temp=this.value;
            var reg= new RegExp('/^[A-Z]{2}[ -][0-9]{1,2}(?: [A-Z])?(?: [A-Z]*)? [0-9]{4}$/g');
            if(!reg.test(temp)){
                this.value='';
                $("#verr").html("enter correct vehicle number").show().fadeOut("slow");
                return false;
            }
        });

        $('#Add').click(function () {
            if($('#addv').val() !='' && $('#addc').val() !='' ) {
            var size = ($('#tableDiv tr').length) - 1;
            if (size < num) {
                $('#tableDiv').append('<tr id=' + rowindex[0] + '><td>' + $('#addv').val() + '</td><td>' + $('#addc').val() + '</td><td>' + rowindex[0] + '</td><td><button type="button"  id=' + rowindex[0] + '>Deallocate</button></td></tr>');
            }
        }
        else{
            alert('type in input details');
            return false;
        }
        });
    });




//    $('table tr button').live("click",function () {
//        
//        alert('hello');
////        rowindex[rowi++]=$(this).parent().index();
////        
////         //alert(rowindex);
////        $('#tableDiv tr')[$(this).parent().index()].remove();
//         
//    });

//    $('#tableDiv tr').click(function () {
//        //rowindex[rowi++]
//        
//    });

//    $("#tableDiv tr button").on('click', function(e){
//        //rowindex[rowi++]=$(this).parent().index();
//        alert($(this).closest('tr').attr('id'));
//        $('#tableDiv tr')[$(this).closest('tr').attr('id')].remove();
//    });





});




